# Paquete del laboratorio B1 — TLS en transito y tunel entre sedes

Servicios: `web` (nginx con TLS en 10.20.0.10:443), `interno` (servicio que **no** publica puertos,
en la red 10.30.0.0/24), y `sede1`/`sede2` (WireGuard) para el tunel entre sedes.

```
mkdir -p web wireguard/sede1 wireguard/sede2
docker compose -p b1 up -d
curl --cacert ca.crt --resolve web.lab:443:10.20.0.10 https://web.lab/
```

El paquete llega a la VM del estudiante con `asur-lab iniciar b1`, que lo deja en `~/labs/b1` y ejecuta
el ciclo de vida con `./lab up`.

## Lo que el estudiante construye (no viene en el paquete)

- `ca.key`, `ca.crt`, `servidor.key`, `servidor.crt`: su CA y su certificado de servidor con
  `subjectAltName=DNS:web.lab,IP:10.20.0.10`. El verificador los lee en el directorio de trabajo,
  asi que se crean en `~/labs/b1`. El certificado del servidor se copia a `web/web.crt` y
  `web/web.key` porque nginx lo lee de `/etc/nginx/certs`. **No** se versionan claves.
- `wireguard/sede1/wg0.conf` y `wireguard/sede2/wg0.conf`: la configuracion del tunel, que genera el
  estudiante en la parte B. `sede2` lleva la salida NAT hacia la red interna, para que el servicio
  interno se vea por el tunel y no por la red del cliente.

Los certificados de `web/` y la carpeta `wireguard/` estan en `.gitignore` del paquete: si alguien los
versiona, estaria publicando claves.

## Aviso de entorno

El `docker-compose.yml` del paquete mapea `/dev/net/tun` a los dos contenedores WireGuard y activa el
reenvio en `sede2`; el anfitrion necesita el modulo `wireguard` y `/dev/net/tun` (en la VM del curso
Ubuntu LTS estan). El verificador `asur-lab check b1-tls` comprueba el handshake y falla con pista si
no existe.

## Que NO esta probado

El paquete se levanto y se valido en la VM del curso: handshake entre sedes, ping por el tunel y acceso
al servicio interno por el tunel, con el servicio interno inalcanzable desde la red del cliente y sin
puertos publicados. La publicacion en la plataforma labs queda pendiente del despliegue con aprobacion
humana.
