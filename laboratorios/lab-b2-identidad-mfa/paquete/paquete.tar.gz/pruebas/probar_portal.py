#!/usr/bin/env python3
"""Prueba el portal de B2 sin Docker: clave con un radtest falso y codigos TOTP reales."""
import json, os, subprocess, sys, tempfile

AQUI = os.path.dirname(os.path.abspath(__file__))
PORTAL = os.path.join(os.path.dirname(AQUI), "portal.py")
USADOS = os.path.join(os.path.dirname(AQUI), "usados.json")
fallos = 0

def chequear(desc, cond, extra=""):
    global fallos
    print(("OK    " if cond else "FALLA ") + desc + ("  :: " + str(extra)[:120] if extra and not cond else ""))
    if not cond:
        fallos += 1

def radtest_falso(directorio, acepta):
    ruta = os.path.join(directorio, "radtest_falso.sh")
    with open(ruta, "w", encoding="utf-8") as f:
        f.write("#!/bin/sh\n")
        f.write("if [ \"$2\" = \"ClaveAna2027\" ]; then echo 'Received %s Id 1'; exit 0; fi\n"
                % ("Access-Accept" if acepta else "Access-Reject"))
        f.write("echo 'Received Access-Reject Id 2'; exit 0\n")
    os.chmod(ruta, 0o755)
    return ruta

def correr(args):
    p = subprocess.run([sys.executable, PORTAL] + args, capture_output=True, text=True)
    return p.returncode, (p.stdout + p.stderr).strip()

tmp = tempfile.mkdtemp()
falso = radtest_falso(tmp, True)
secreto = "JBSWY3DPEHPK3PXP"
registro = os.path.join(tmp, "secretos.json")
with open(registro, "w", encoding="utf-8") as f:
    json.dump({"ana": secreto}, f)

sys.path.insert(0, os.path.dirname(AQUI))
import portal as mod

codigo = mod.totp(secreto, 1000000)
codigo_viejo = mod.totp(secreto, 1000000 - 30)

c, out = correr(["--correo", "ana", "--clave", "ClaveAna2027", "--comando", falso + " {correo} {clave}",
                 "--secretos", registro])
chequear("solo con clave, el portal rechaza por falta de segundo factor", c == 1 and "falta el segundo factor" in out, out)

c, out = correr(["--correo", "ana", "--clave", "mala", "--comando", falso + " {correo} {clave}",
                 "--secretos", registro, "--codigo", codigo, "--ahora", "1000000"])
chequear("con clave mala, el portal rechaza por identidad", c == 1 and "rechazadas" in out, out)

open(USADOS, "w").write("{}")
c, out = correr(["--correo", "ana", "--clave", "ClaveAna2027", "--comando", falso + " {correo} {clave}",
                 "--secretos", registro, "--codigo", codigo, "--ahora", "1000000"])
chequear("clave buena y codigo del momento: acceso concedido", c == 0 and "ACCESO CONCEDIDO" in out, out)

c, out = correr(["--correo", "ana", "--clave", "ClaveAna2027", "--comando", falso + " {correo} {clave}",
                 "--secretos", registro, "--codigo", codigo, "--ahora", "1000000"])
chequear("el mismo codigo otra vez se rechaza por usado", c == 1 and "ya usado" in out, out)

c, out = correr(["--correo", "ana", "--clave", "ClaveAna2027", "--comando", falso + " {correo} {clave}",
                 "--secretos", registro, "--codigo", codigo_viejo, "--ahora", "1000000"])
chequear("un codigo anterior al ultimo aceptado no vuelve a servir", c == 1 and "ya usado" in out, out)

c, out = correr(["--correo", "ana", "--clave", "ClaveAna2027", "--comando", falso + " {correo} {clave}",
                 "--secretos", registro, "--codigo", "000000", "--ahora", "1000000"])
chequear("un codigo inventado se rechaza", c == 1 and ("no valido" in out or "fuera de la ventana" in out), out)

c, out = correr(["--correo", "luis", "--clave", "ClaveAna2027", "--comando", falso + " {correo} {clave}",
                 "--secretos", registro, "--codigo", codigo, "--ahora", "1000000"])
chequear("el codigo de otro usuario no sirve para luis", c == 1, out)

c, out = correr(["--correo", "ana", "--clave", "ClaveAna2027", "--comando", "exit 127 {correo}",
                 "--secretos", registro, "--codigo", codigo])
chequear("si la identidad no responde, el portal lo dice y no concede", c == 1 and "no respondio" in out, out)

codigo2 = mod.totp(secreto, 1000030)
c, out = correr(["--correo", "ana", "--clave", "ClaveAna2027", "--comando", falso + " {correo} {clave}",
                 "--secretos", registro, "--codigo", codigo2, "--ahora", "1000030"])
chequear("el codigo del paso siguiente si entra", c == 0 and "ACCESO CONCEDIDO" in out, out)

contenido = open(USADOS, encoding="utf-8").read()
chequear("el portal guarda el ultimo contador usado, sin el codigo", "ana" in contenido and codigo2 not in contenido, contenido)

os.unlink(USADOS)
print("RESULTADO: " + ("todas las pruebas pasan" if fallos == 0 else "%d fallos" % fallos))
sys.exit(fallos)