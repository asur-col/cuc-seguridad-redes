#!/usr/bin/env python3
"""Portal del laboratorio B2: exige clave (contra el servicio de identidad) y codigo TOTP.

Uso:
  python3 portal.py --correo ana --clave ClaveAna2027
  python3 portal.py --correo ana --clave ClaveAna2027 --codigo 123456

La clave se valida contra el servicio de identidad con el comando indicado en --comando
(por defecto radtest dentro del contenedor del laboratorio). El codigo se valida con el
secreto del usuario y se recuerda el ultimo aceptado para que no sirva dos veces.
"""
import argparse, base64, hashlib, hmac, json, os, struct, subprocess, sys, time

AQUI = os.path.dirname(os.path.abspath(__file__))
USADOS = os.path.join(AQUI, "usados.json")
COMANDO = "docker exec lab-b2-cliente radtest {correo} {clave} 10.40.0.10 0 secreto-del-laboratorio"
PASO = 30
VENTANA = 1

def totp(secreto_b32, momento=None, paso=PASO, digitos=6):
    momento = int(momento if momento is not None else time.time())
    clave = base64.b32decode(secreto_b32.strip().upper() + "=" * ((8 - len(secreto_b32.strip()) % 8) % 8))
    contador = momento // paso
    mensaje = struct.pack(">Q", contador)
    h = hmac.new(clave, mensaje, hashlib.sha1).digest()
    desplazamiento = h[-1] & 0x0F
    codigo = (struct.unpack(">I", h[desplazamiento:desplazamiento + 4])[0] & 0x7FFFFFFF) % (10 ** digitos)
    return str(codigo).zfill(digitos)

def contador_de(secreto_b32, codigo, momento=None):
    """Devuelve el contador que genera ese codigo dentro de la ventana, o None."""
    momento = int(momento if momento is not None else time.time())
    actual = momento // PASO
    for d in range(-VENTANA, VENTANA + 1):
        if totp(secreto_b32, (actual + d) * PASO) == str(codigo).strip():
            return actual + d
    return None

def clave_valida(correo, clave, comando):
    try:
        r = subprocess.run(comando.format(correo=correo, clave=clave), shell=True,
                           capture_output=True, text=True, timeout=15)
    except Exception:
        return False, "no se pudo consultar el servicio de identidad"
    salida = (r.stdout or "") + (r.stderr or "")
    if "Access-Accept" in salida:
        return True, "identidad confirmada"
    if "Access-Reject" in salida:
        return False, "credenciales rechazadas por el servicio de identidad"
    return False, "el servicio de identidad no respondio"

def leer_usados():
    try:
        with open(USADOS, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {}

def guardar_usados(d):
    with open(USADOS, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)

def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--correo", required=True)
    ap.add_argument("--clave", required=True)
    ap.add_argument("--codigo")
    ap.add_argument("--secretos", default=os.path.join(AQUI, "secretos.json"),
                    help="registro de secretos por cuenta (defecto: secretos.json)")
    ap.add_argument("--comando", default=COMANDO, help="comando de validacion de clave; usa {correo} y {clave}")
    ap.add_argument("--ahora", type=int, help="momento en segundos, solo para pruebas")
    a = ap.parse_args(argv)

    ok, motivo = clave_valida(a.correo, a.clave, a.comando)
    if not ok:
        print("RECHAZO " + motivo)
        return 1
    if not a.codigo:
        print("RECHAZO falta el segundo factor")
        return 1

    try:
        with open(a.secretos, encoding="utf-8") as f:
            registro = json.load(f)
    except (OSError, json.JSONDecodeError):
        registro = {}
    secreto = registro.get(a.correo)
    if not secreto:
        # La guia hace que el estudiante guarde el secreto en <correo>.secreto: se acepta tambien.
        try:
            with open(os.path.join(AQUI, "%s.secreto" % a.correo), encoding="utf-8") as f:
                secreto = f.read().strip()
        except OSError:
            secreto = None
    if not secreto:
        print("RECHAZO no hay secreto registrado para esa cuenta")
        return 1

    contador = contador_de(secreto, a.codigo, a.ahora)
    if contador is None:
        print("RECHAZO codigo no valido o fuera de la ventana")
        return 1

    usados = leer_usados()
    ultimo = usados.get(a.correo)
    if ultimo is not None and contador <= int(ultimo):
        print("RECHAZO codigo ya usado")
        return 1

    usados[a.correo] = contador
    guardar_usados(usados)
    print("ACCESO CONCEDIDO")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
