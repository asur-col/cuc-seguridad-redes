# Paquete del laboratorio B2 — identidad y segundo factor

Servicio de identidad (FreeRADIUS) en 10.40.0.10 y un cliente de pruebas en 10.40.0.20. El portal
`portal.py` exige clave válida contra ese servicio y un código de un solo uso.

```
docker compose up -d
python3 portal.py --correo ana --clave ClaveAna2027          # rechaza: falta el segundo factor
python3 portal.py --correo ana --clave ClaveAna2027 --codigo 123456
```

- `radius/clients.conf`: cliente y secreto compartido del laboratorio (no es un secreto real).
- `radius/authorize`: usuarios del laboratorio con clave en claro; en clase se discute por qué esto
  no se hace en producción y qué lo sustituye.
- `secretos.json`: registro de secretos TOTP por cuenta (`{"ana": "BASE32..."}`). Lo crea el
  estudiante en el paso B.3; el paquete **no** lo trae.
- `usados.json`: lo escribe el portal con el último contador aceptado por cuenta. Sin ese archivo,
  un código robado serviría dos veces.

## Pruebas del portal (sin Docker)

```
python3 pruebas/probar_portal.py     # 10 comprobaciones, clave con un radtest falso y códigos reales
```

Las pruebas usan un comando de identidad falso (`--comando`), así que no necesitan el contenedor.
Lo que **no** está probado aquí es el contenedor de FreeRADIUS ni `radtest` reales: eso es Fase 5.
