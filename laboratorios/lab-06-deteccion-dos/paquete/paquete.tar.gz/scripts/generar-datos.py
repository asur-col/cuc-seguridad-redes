#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# scripts/generar-datos.py — Lab 6 · Seguridad en Redes · U. de la Costa 2026-2
#
# Genera los pcaps del lab con IPs privadas ficticias y MAC fijas que
# coinciden con las de los contenedores, y construye datos/dataset.csv con
# features por ventana de 1 s (pps, syn_ratio, ips_unicas, req_http,
# etiqueta) para el Lab 7.
#
# Pcaps generados — valores conocidos que usa ./lab check (objetivo 2):
#   normal.pcap:       3 orígenes · 1 flujo/s por origen · ~18 pps · 30 s
#   syn-flood.pcap:    1 origen   · 100 SYN/s            · 15 s  · 1500 paq
#   http-flood.pcap:   1 origen   · 25 peticiones/s      · 10 s  · 1250 paq
#   multi-origen.pcap: 20 orígenes· 12 SYN/s por origen  · 20 s  · 4800 paq
#
# El destino es SIEMPRE el servidor del laboratorio (10.30.0.10, red Docker
# internа) con la MAC de la interfaz lan-clientes del router fw. Solo
# reproduce tráfico con IPs privadas RFC1918: sin herramientas ofensivas.

import os
import random
import socket
import struct

RUTA = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "datos")
random.seed(20261027)

MAC_FW_LAN_CLIENTES = "02:6c:20:10:00:01"    # eth0 del router fw
MAC_FW_LAN_SERVIDOR = "02:6c:30:00:00:01"    # eth1 (lan-servidor)
IP_WEB              = "10.30.0.10"
ETH_P_IP            = 0x0800

# --- armado de paquetes (solo stdlib) ----------------------------------------


def mac_bin(m):
    return bytes(int(x, 16) for x in m.split(":"))


def eth(src, dst):
    return mac_bin(dst) + mac_bin(src) + struct.pack(">H", ETH_P_IP)


def chksum(data):
    if len(data) % 2:
        data += b"\x00"
    s = 0
    for i in range(0, len(data), 2):
        s += (data[i] << 8) | data[i + 1]
    while s >> 16:
        s = (s & 0xFFFF) + (s >> 16)
    return ~s & 0xFFFF


def tcp_seg(src_ip, dst_ip, sport, dport, seq, ack, flags, win, payload=b""):
    # Cabecera TCP (sin opciones) + checksum con pseudo-cabecera.
    hdr = struct.pack(">HHIIBBHHH", sport, dport, seq, ack,
                      5 << 4, flags, win, 0, 0)
    pseudo = socket.inet_aton(src_ip) + socket.inet_aton(dst_ip) + \
        struct.pack(">BBH", 0, 6, 20 + len(payload))
    csum = chksum(pseudo + hdr + payload)
    hdr = hdr[:16] + struct.pack(">H", csum) + hdr[18:]
    total = 20 + len(payload)
    ip = struct.pack(">BBHHHBBH", 0x45, 0, total, random.randint(1, 65535),
                     0x4000, 64, 6, 0) + \
        socket.inet_aton(src_ip) + socket.inet_aton(dst_ip)
    ip = ip[:10] + struct.pack(">H", chksum(ip)) + ip[12:]
    return eth(None, None) + ip + hdr + payload


def eth_fix(src_mac, dst_mac, cuerpo):
    return mac_bin(dst_mac) + mac_bin(src_mac) + struct.pack(">H", ETH_P_IP) + cuerpo


def tcp_(src_ip, dst_ip, sport, dport, seq, ack, flags, win, payload=b""):
    hdr = struct.pack(">HHIIBBHHH", sport, dport, seq, ack,
                      5 << 4, flags, win, 0, 0)
    pseudo = socket.inet_aton(src_ip) + socket.inet_aton(dst_ip) + \
        struct.pack(">BBH", 0, 6, 20 + len(payload))
    csum = chksum(pseudo + hdr + payload)
    hdr = hdr[:16] + struct.pack(">H", csum) + hdr[18:]
    total = 20 + len(payload)
    ip = struct.pack(">BBHHHBBH", 0x45, 0, total, random.randint(1, 65535),
                     0x4000, 64, 6, 0) + \
        socket.inet_aton(src_ip) + socket.inet_aton(dst_ip)
    ip = ip[:10] + struct.pack(">H", chksum(ip)) + ip[12:]
    return ip + hdr + payload


def marco(src_mac, dst_mac, ip_tx):
    return mac_bin(dst_mac) + mac_bin(src_mac) + struct.pack(">H", ETH_P_IP) + ip_tx


FIN, SYN, RST, PSH, ACK = 1, 2, 4, 8, 16


def flujo_completo(w, t, src_mac, ip, sport, url="/"):
    """SYN, SYN-ACK, ACK, GET, RESP, FIN de un cliente HTTPRFC por 0.002 s."""
    dst_mac = MAC_FW_LAN_CLIENTES
    seq = random.randint(1000, 100000)
    cuerpo = ("GET %s HTTP/1.1\r\nHost: 10.30.0.10\r\n"
              "User-Agent: lab06/1.0\r\n\r\n" % url).encode()
    respuesta = (b"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n"
                 b"Content-Length: 28\r\n\r\n<html><body>Lab 6</body></html>")
    w.agregar(t, marco(src_mac, dst_mac,
              tcp_(ip, IP_WEB, sport, 80, seq, 0, SYN, 14600)))
    w.agregar(t + 0.0004, marco(dst_mac, src_mac,
              tcp_(IP_WEB, ip, 80, sport, seq + 1, seq + 1, SYN | ACK, 14600)))
    w.agregar(t + 0.0006, marco(src_mac, dst_mac,
              tcp_(ip, IP_WEB, sport, 80, seq + 1, seq + 1, ACK, 14600)))
    w.agregar(t + 0.0009, marco(src_mac, dst_mac,
              tcp_(ip, IP_WEB, sport, 80, seq + 1, seq + 1, PSH | ACK, 14600, cuerpo)))
    w.agregar(t + 0.0012, marco(dst_mac, src_mac,
              tcp_(IP_WEB, ip, 80, sport, seq + 1 + len(cuerpo), seq + 1 + len(cuerpo),
                   PSH | ACK, 14600, respuesta)))
    w.agregar(t + 0.0016, marco(src_mac, dst_mac,
              tcp_(ip, IP_WEB, sport, 80, seq + 1 + len(cuerpo), seq + 1 + len(respuesta),
                   FIN | ACK, 14600)))


def flujo_syn(w, t, src_mac, ip, sport, seq=1):
    """Solo SYN (medio saludo): la pila del servidor provoca SYN-RECV."""
    w.agregar(t, marco(src_mac, MAC_FW_LAN_CLIENTES,
              tcp_(ip, IP_WEB, sport, 80, seq, 0, SYN, 1024)))


def mac_of(i):
    return "02:6c:20:10:00:%02x" % i


class EscritorPcap:
    """Escritor pcap minimalista (linktype Ethernet, timestamps µs)."""

    def __init__(self, path):
        self.f = open(path, "wb")
        self.f.write(struct.pack("<IHHiIII", 0xa1b2c3d4, 2, 4, 0, 0, 65535, 1))

    def agregar(self, ts, frame):
        entero = int(ts)
        micro = int(round((ts - entero) * 1e6))
        if micro >= 1000000:
            entero += micro // 1000000
            micro %= 1000000
        self.f.write(struct.pack("<IIII", entero, micro, len(frame), len(frame)))
        self.f.write(frame)

    def cerrar(self):
        self.f.close()


URLS = ["/", "/index.html", "/equipo.html", "/cupones.html", "/blog/"]


def gen_normal(duracion=30):
    """Tráfico legítimo: 3 clientes, 1 flujo/s cada uno (~18 pps en total)."""
    path = os.path.join(RUTA, "normal.pcap")
    w = EscritorPcap(path)
    clientes = [(("10.20.10.%d" % (11 + i)).__str__(), mac_of(11 + i)) for i in range(3)]
    t = 0.0
    for _ in range(duracion):
        for ip, mac in clientes:
            sport = random.randint(40000, 61000)
            flujo_completo(w, t, mac, ip, sport, random.choice(URLS))
        t += 1.0
    w.cerrar()
    return path


def gen_syn_flood(duracion=15, tasa=100):
    """SYN flood de una sola IP: 100 SYN/s por 15 s = 1500 paquetes."""
    path = os.path.join(RUTA, "syn-flood.pcap")
    w = EscritorPcap(path)
    ip, mac = "10.20.10.71", mac_of(0x71)
    t, paso = 0.0, 1.0 / tasa
    for i in range(int(duracion * tasa)):
        flujo_syn(w, t, mac, ip, 40000 + (i % 20000), i * 1460)
        t += paso
    w.cerrar()
    return path


def gen_http_flood(duracion=10, tasa=25):
    """HTTP flood con sesiones completas: 25 GET/s = 125 paquetes/s."""
    path = os.path.join(RUTA, "http-flood.pcap")
    w = EscritorPcap(path)
    ip, mac = "10.20.10.91", mac_of(0x91)
    t, paso = 0.0, 1.0 / tasa
    for i in range(int(duracion * tasa)):
        flujo_completo(w, t, mac, ip, 45000 + i, "/")
        t += paso
    w.cerrar()
    return path


def gen_multi_origen(origenes=20, por_origen=12, duracion=20):
    """Multi-origen distribuido: 20 IPs de la lan-clientes, 12 SYN/s cada una."""
    path = os.path.join(RUTA, "multi-origen.pcap")
    w = EscritorPcap(path)
    brew = [("10.20.10.%d" % (60 + i), mac_of(60 + i)) for i in range(origenes)]
    paso = 1.0 / por_origen
    t = 0.0
    for _ in range(duracion):
        for j, (ip, mac) in enumerate(brew):
            for k in range(por_origen):
                flujo_syn(w, t + j * paso + k * 0.02, mac, ip,
                          41000 + (j * 100 + k) % 9000, random.randint(1, 2 ** 30))
        t += 1.0
    w.cerrar()
    return path


def dataset_csv():
    """Features por ventana de 1 s de los cuatro pcaps, con etiqueta."""
    path = os.path.join(RUTA, "dataset.csv")
    filas = []
    for archivo, etiqueta in [("normal.pcap", "normal"),
                              ("syn-flood.pcap", "syn-flood"),
                              ("http-flood.pcap", "http-flood"),
                              ("multi-origen.pcap", "multi-origen")]:
        d = open(os.path.join(RUTA, archivo), "rb").read()
        off = 24
        por_ventana = {}
        while off + 16 <= len(d):
            ts_s, ts_us, incl, _orig = struct.unpack_from("<IIII", d, off)
            off += 16
            paq = d[off: off + incl]
            off += incl
            if len(paq) < 54:
                continue
            por_ventana.setdefault(int(ts_s + ts_us / 1e6), []).append(paq)
        for w in sorted(por_ventana):
            paq = por_ventana[w]
            pps = len(paq)
            syn, srcs, req = 0, set(), 0
            for p in paq:
                ihl = (p[14] & 0x0F) * 4
                off_tcp = 14 + ihl
                if len(p) < off_tcp + 20:
                    continue
                flags = p[off_tcp + 13]
                ip_payload = len(p) - off_tcp
                srcs.add(socket.inet_ntoa(p[26:30]))
                if (flags & SYN) and not (flags & ACK):
                    syn += 1
                if ip_payload > 20 and p[off_tcp + 20:off_tcp + 24] == b"GET ":
                    req += 1
            syn_ratio = round(syn / max(pps, 1), 3)
            filas.append((pps, syn_ratio, len(srcs), req, etiqueta))
    with open(path, "w") as f:
        f.write("pps,syn_ratio,ips_unicas,req_http,etiqueta\n")
        for fila in filas:
            f.write("%d,%s,%d,%d,%s\n" % fila)


def main():
    os.makedirs(RUTA, exist_ok=True)
    for p in [gen_normal(), gen_syn_flood(), gen_http_flood(), gen_multi_origen()]:
        print("pcap %7.1f KB  %s" % (os.path.getsize(p) / 1024.0, os.path.basename(p)))
    dataset_csv()
    print("dataset.csv %7.1f KB  datos/dataset.csv" %
          (os.path.getsize(os.path.join(RUTA, "dataset.csv")) / 1024.0))


if __name__ == "__main__":
    main()
