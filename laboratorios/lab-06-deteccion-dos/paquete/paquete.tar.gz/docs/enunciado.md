# Lab 6 — Detección y mitigación de tráfico anómalo (DoS/DDoS)
