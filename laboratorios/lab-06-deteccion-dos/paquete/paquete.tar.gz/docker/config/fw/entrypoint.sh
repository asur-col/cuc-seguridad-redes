#!/bin/sh
# fw del Lab 6 — router nftables entre lan-clientes (10.20.10.0/24) y
# lan-servidor (10.30.0.0/24). Identifica interfaces por subred, fija las
# MAC que esperan los pcap, sienta vecinos ARP estáticos, desactiva el
# offloading de checksum de Docker/veth y carga reglas/nftables.fw.

set -u

ethtool -K eth0 rx off tx off 2>/dev/null || true
ethtool -K eth1 rx off tx off 2>/dev/null || true

E_CLIENTES=$(ip -o addr | awk '$4 ~ /^10\.20\.10\./ {print $2; exit}')
E_SERVIDOR=$(ip -o addr | awk '$4 ~ /^10\.30\.0\./ {print $2; exit}')
[ -n "$E_CLIENTES" ] && [ -n "$E_SERVIDOR" ] || {
  echo "fw: ERROR: no pude identificar las interfaces por subred"; exit 1; }

# MAC conocidas: lan-clientes es el destino de los fotogramas que reproduce
# tcpreplay desde el generador (02:6c:20:10:00:01).
ip link set dev "$E_CLIENTES" address 02:6c:20:10:00:01 || true
ip link set dev "$E_SERVIDOR" address 02:6c:30:00:00:01 || true

sysctl -w net.ipv4.ip_forward=1 >/dev/null 2>&1 || true
sysctl -w net.ipv4.conf.all.proxy_arp=1 >/dev/null 2>&1 || true
sysctl -w net.ipv4.conf.default.rp_filter=0 >/dev/null 2>&1 || true

ip neigh replace 10.20.10.21 lladdr 02:6c:20:10:00:15 dev "$E_CLIENTES" nud permanent || true
ip neigh replace 10.20.10.50 lladdr 02:6c:20:10:00:32 dev "$E_CLIENTES" nud permanent || true
ip neigh replace 10.30.0.10   lladdr 02:6c:30:00:00:0a dev "$E_SERVIDOR" nud permanent || true
i=60
while [ $i -le 99 ]; do
  ip neigh replace "10.20.10.$i" lladdr 02:6c:f0:00:00:99 dev "$E_CLIENTES" nud permanent || true
  i=$((i+1))
done
ip neigh replace 10.20.10.71 lladdr 02:6c:f0:00:00:71 dev "$E_CLIENTES" nud permanent || true
ip neigh replace 10.20.10.91 lladdr 02:6c:f0:00:00:91 dev "$E_CLIENTES" nud permanent || true

if [ -s /lab06/reglas/nftables.fw ]; then
  nft -f /lab06/reglas/nftables.fw || \
    echo "fw: AVISO: reglas/nftables.fw tiene errores de sintaxis; no se cargó nada" >&2
else
  echo "fw: aviso: no existe reglas/nftables.fw; el tráfico cruza sin filtrar" >&2
fi

echo "fw: listo — $E_CLIENTES (lan-clientes) ⟷ $E_SERVIDOR (lan-servidor)"
exec tail -f /dev/null
