#!/bin/bash
# ids del Lab 6 — lanza Suricata en modo IDS (af-packet) sobre la interfaz
# lan-clientes de fw (la misma que comparte namespace de red) y mantiene el
# contenedor vivo. Las reglas del estudiante viven en /etc/suricata/rules/
# lab.rules (bind mount de reglas/lab.rules); ./lab recarga reinicia Suricata.

IFACE=$(ip -o addr | awk '$4 ~ /^10\.20\.10\./ {print $2; exit}')
[ -n "$IFACE" ] || { echo "ERROR: no encontré la interfaz lan-clientes (10.20.10.0/24)" >&2; exit 1; }

# Sustituye la interfaz del af-packet en la configuración (se aplica a la
# eth que docker compose haya asignado a esa subred).
sed -i "s/^  - interface: .*/  - interface: $IFACE/" /etc/suricata/suricata.yaml

rm -f /var/run/suricata.pid
mkdir -p /var/log/suricata
rm -f /var/log/suricata/eve.json /var/log/suricata/fast.log

nohup suricata -c /etc/suricata/suricata.yaml --af-packet \
      >/var/log/suricata/suricata.log 2>&1 &

echo "suricata iniciado en $IFACE; alertas en /var/log/suricata/eve.json"
exec tail -f /dev/null
