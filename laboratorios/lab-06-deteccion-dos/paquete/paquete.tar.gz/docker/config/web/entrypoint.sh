#!/bin/sh
# entrypoint del «web» (Lab 6): desactiva el offloading de checksum de
# Docker/veth (si el kernel lo permite), fija la ruta por defecto hacia el
# router interno 10.30.0.2 y arranca nginx.

set -e
ethtool -K eth0 rx off tx off 2>/dev/null || true
ip route replace default via 10.30.0.2 2>/dev/null || true
mkdir -p /var/log/nginx
touch /var/log/nginx/lab-access.log
chmod 644 /var/log/nginx/lab-access.log 2>/dev/null || true
exec nginx -g "daemon off;"
