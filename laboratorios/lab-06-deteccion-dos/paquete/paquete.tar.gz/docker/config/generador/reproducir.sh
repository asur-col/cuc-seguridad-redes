#!/bin/bash
# Generador del Lab 6 — reproduce capturas pregrabadas contra el servidor
# objetivo del lab (10.30.0.10, red Docker interna).
#
# MARCO ÉTICO Y DEFENSIVO:
#   - Solo reproduce los pcap pregrabados de /datos; no acepta parámetros
#     de destino ni de tasa: están fijados aquí (no es configurable).
#   - El destino es SIEMPRE el servidor de este laboratorio (10.30.0.10,
#     red Docker internal). Nunca alcanza redes externas.
#   - Ley 1273 de 2009 (Colombia): esta herramienta es para defender
#     entornos propios y autorizados, no para atacar terceros.

set -u
MODO="${1:-}"
[ -z "$MODO" ] && { echo "uso: reproducir.sh <syn|http|multi>" >&2; exit 2; }

IFACE=eth0
LOG=/var/log/generador/reproduccion.log
mkdir -p "$(dirname "$LOG")" 2>/dev/null

#af Ips privadas RFC1918 dentro del lab (IPs ficticias del pcap).
case "$MODO" in
  syn)
    # SYN flood: 1 origen, 100 SYN/s por 15 s (1500 paquetes).
    echo "$(date +%s) inicio syn" >> "$LOG"
    tcpreplay --quiet --intf1="$IFACE" --pps=100 /datos/syn-flood.pcap
    rc=$?
    echo "$(date +%s) fin syn rc=$rc" >> "$LOG"
    ;;
  http)
    # HTTP flood: 1 origen, 25 GET/s (125 paq/s) por 10 s.
    echo "$(date +%s) inicio http" >> "$LOG"
    tcpreplay --quiet --intf1="$IFACE" --pps=125 /datos/http-flood.pcap
    rc=$?
    echo "$(date +%s) fin http rc=$rc" >> "$LOG"
    ;;
  multi)
    # Distribuido: 20 orígenes, 12 SYN/s cada uno (240 pps en total) por 20 s.
    echo "$(date +%s) inicio multi" >> "$LOG"
    tcpreplay --quiet --intf1="$IFACE" --pps=240 /datos/multi-origen.pcap
    rc=$?
    echo "$(date +%s) fin multi rc=$rc" >> "$LOG"
    ;;
  *)
    echo "modo desconocido: $MODO" >&2
    exit 2
    ;;
esac
exit "${rc:-0}"
