#!/bin/sh
# entrypoint del «generador» (Lab 6): desactiva offloading de checksum y se
# queda a la espera de ./lab ataque / ./lab check (reproducir.sh).

set -e
ethtool -K eth0 rx off tx off 2>/dev/null || true
ip route replace default via 10.20.10.2 2>/dev/null || true
exec sleep infinity
