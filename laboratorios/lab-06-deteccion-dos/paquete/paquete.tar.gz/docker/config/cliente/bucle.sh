#!/bin/sh
# Bucle del cliente legítimo: pide la ruta /health del servidor objetivo
# cada 1 segundo (timeout 3 s) y guarda las respuestas para poder calcular
# el porcentaje de éxito.
#
# Formato de la línea: <seg> <código> <duración_ms>

LOG=/var/log/cliente/respuestas.log
URL=http://10.30.0.10/health

while true; do
  t=$(date +%s)
  cod="000"
  dur="0"
  if out=$(curl -s -o /dev/null -w "%{http_code} %{time_total}" --max-time 3 "$URL" 2>/dev/null); then
    cod=$(echo "$out" | cut -d' ' -f1)
    dur=$(echo "$out" | cut -d' ' -f2)
  fi
  echo "$t $cod ${dur}s" >> "$LOG"
  sleep 1
done
