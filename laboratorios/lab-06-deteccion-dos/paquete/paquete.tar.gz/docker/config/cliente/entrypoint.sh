#!/bin/sh
# entrypoint del «cliente» (Lab 6): desactiva offloading de checksum, fija
# la ruta por defecto hacia el router 10.20.10.2 y deja el contenedor vivo.
# El bucle de peticiones /health se lanza aparte (./lab base o el estudiante).

set -e
ip link set dev eth0 address 02:6c:20:10:00:15 2>/dev/null || true
ethtool -K eth0 rx off tx off sg off tso off gso off gro off lro off 2>/dev/null || true
ip route replace default via 10.20.10.2 2>/dev/null || true
exec tail -f /dev/null
