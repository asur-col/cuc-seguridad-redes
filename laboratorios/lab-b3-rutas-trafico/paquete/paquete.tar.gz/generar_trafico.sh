#!/bin/sh
# Genera el trafico del ejercicio: uno que sale, uno que llega y uno que se corta.
set -e
echo "1. del cliente al servidor interno:"
docker exec lab-b3-cliente wget -q -O /dev/null http://10.30.0.20/ && echo "   interno respondio"

echo "2. del cliente a internet (destino autorizado del laboratorio):"
docker exec lab-b3-cliente wget -q -O /dev/null http://10.40.0.10/ && echo "   externo respondio"

echo "3. del cliente al puerto de administracion, que debe cortarse:"
docker exec lab-b3-cliente wget -T 3 -q -O /dev/null http://10.30.0.20:9000/ || echo "   cortado, como debe ser"

echo "4. contadores del router:"
docker exec lab-b3-router iptables -t nat -L POSTROUTING -v -n
docker exec lab-b3-router iptables -L FORWARD -v -n
