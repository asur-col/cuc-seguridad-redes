# Visor de rutas y tráfico (Fase 4)

El estudiante ve, sobre la topología real del laboratorio, por dónde va cada paquete: qué contenedor
lo vio, con qué origen y destino, en qué momento, si el router lo tradujo (NAT) y si el firewall lo
bloqueó. No hay animación: cada salto es una línea de `tcpdump` capturada en un contenedor concreto.
Si un contenedor no vio el paquete, ese salto no aparece.

## Cómo se usa

```
python3 colector.py --contenedores lab-b3-cliente,lab-b3-router,lab-b3-interno --puerto 8099
# abrir http://IP-VM:8099/
```

Botones: **generar tráfico** al servidor interno o a la salida autorizada, **filtrar** por IP, puerto o
protocolo, y **ver reglas del router** (`iptables -t nat -L -v -n` e `iptables -L -v -n`), que es lo que
explica por qué un paquete pasó o se quedó en el camino.

## Modos

| Modo | Para qué |
|---|---|
| `--fuente docker` | captura real: `docker exec <contenedor> tcpdump -i any -nn -e -l -q` |
| `--fuente archivo=RUTA` | analiza líneas ya capturadas (pruebas del analizador, sin contenedores) |

## Pruebas

```
python3 pruebas/probar_visor.py    # 10 comprobaciones del analizador y de la API
python3 pruebas/probar_pagina.py   # navegador real: consola limpia y filas pintadas
```

`pruebas/flujo_ejemplo.txt` es un **fixture de formato**, no una captura del laboratorio: existe solo
para probar el analizador sin contenedores y así está marcado en el archivo. La captura real se toma en
la VM durante la Fase 5; el visor la muestra igual.

## Límites

- El tráfico de salida se limita a destinos autorizados del laboratorio (`ejemplo.lab` en la topología).
- El visor escucha en la red de la VM; no se publica fuera de ella.
- Si `tcpdump` no está en un contenedor, ese salto se pierde: el visor lo dice en pantalla en lugar de
  inventarlo.