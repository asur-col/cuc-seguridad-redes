#!/bin/sh
# Reglas del router del laboratorio B3. Se ejecutan al arrancar el contenedor.
set -e

# Traduccion de direcciones para que la red interna salga con la cara del router.
# Sin -o eth1 a proposito: el nombre de la interfaz depende del orden en que Docker
# conecta las redes y cambia entre equipos. La regla va por origen, que es estable.
iptables -t nat -A POSTROUTING -s 10.20.0.0/24 -j MASQUERADE

# Lo que entra de la red interna al servidor web interno se permite.
iptables -A FORWARD -s 10.20.0.0/24 -d 10.30.0.20 -p tcp --dport 80 -j ACCEPT

# La red interna puede consultar al servidor de fuera, pero solo en el 80.
iptables -A FORWARD -s 10.20.0.0/24 -d 10.40.0.10 -p tcp --dport 80 -j ACCEPT

# El puerto de administracion del servidor interno no se cruza desde la red interna.
iptables -A FORWARD -s 10.20.0.0/24 -d 10.30.0.20 -p tcp --dport 9000 -j DROP

# Respuestas de las conexiones ya permitidas.
iptables -A FORWARD -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
iptables -A FORWARD -j DROP
echo "reglas del router cargadas"
