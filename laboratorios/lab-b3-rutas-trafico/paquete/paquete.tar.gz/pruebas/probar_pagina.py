#!/usr/bin/env python3
"""Comprueba la pagina del visor en un navegador real: consola limpia y filas pintadas."""
import json, os, signal, subprocess, sys, time, urllib.request
from playwright.sync_api import sync_playwright
AQUI = os.path.dirname(os.path.abspath(__file__))
VISOR = os.path.join(os.path.dirname(AQUI), 'colector.py')
FIJO = os.path.join(AQUI, 'flujo_ejemplo.txt')
PUERTO = int(os.environ.get('PUERTO_PRUEBA', '18097'))
p = subprocess.Popen([sys.executable, VISOR, '--fuente', 'archivo=' + FIJO, '--puerto', str(PUERTO)],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
fallos = 0
try:
    for _ in range(80):
        try:
            urllib.request.urlopen('http://127.0.0.1:%d/salud' % PUERTO, timeout=0.5); break
        except Exception: time.sleep(0.1)
    with sync_playwright() as pw:
        b = pw.chromium.launch(); pg = b.new_page()
        errores = []
        pg.on('console', lambda m: errores.append(m.text) if m.type == 'error' else None)
        pg.goto('http://127.0.0.1:%d/' % PUERTO); pg.wait_for_timeout(2600)
        filas = pg.eval_on_selector_all('#filas tr', 'e => e.length')
        textos = pg.inner_text('#filas')
        b.close()
    print('filas pintadas:', filas, '| errores de consola:', errores)
    if errores: fallos += 1
    if filas < 4: fallos += 1; print('FALLA faltan filas')
    if 'NAT' not in textos: fallos += 1; print('FALLA no se ve la marca NAT')
    if 'bloqueado' not in textos: fallos += 1; print('FALLA no se ve el bloqueo')
    print('RESULTADO: ' + ('pagina correcta' if fallos == 0 else '%d fallos' % fallos))
finally:
    p.send_signal(signal.SIGTERM)
    try: p.wait(timeout=5)
    except Exception: p.kill()
sys.exit(fallos)