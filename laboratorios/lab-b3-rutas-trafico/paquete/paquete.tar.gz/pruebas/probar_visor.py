#!/usr/bin/env python3
"""Prueba del visor de trafico con la fuente de archivo (sin contenedores ni VM)."""
import json, os, signal, subprocess, sys, time, urllib.error, urllib.request
AQUI = os.path.dirname(os.path.abspath(__file__))
VISOR = os.path.join(os.path.dirname(AQUI), 'colector.py')
FIJO = os.path.join(AQUI, 'flujo_ejemplo.txt')
PUERTO = 18099
fallos = 0
def chequear(desc, cond, extra=''):
    global fallos
    print(('OK    ' if cond else 'FALLA ') + desc + (' :: ' + str(extra) if extra else ''))
    if not cond: fallos += 1
def pedir(ruta):
    with urllib.request.urlopen('http://127.0.0.1:%d%s' % (PUERTO, ruta), timeout=10) as r:
        return r.status, r.read().decode('utf-8', 'replace')
def esperar(seg=12):
    import socket
    for _ in range(seg * 10):
        try:
            s = socket.create_connection(('127.0.0.1', PUERTO), 0.3); s.close(); return True
        except OSError: time.sleep(0.1)
    return False
p = subprocess.Popen([sys.executable, VISOR, '--fuente', 'archivo=' + FIJO, '--puerto', str(PUERTO)],
                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
try:
    assert esperar(), 'el visor no arranca'
    c, cuerpo = pedir('/salud')
    j = json.loads(cuerpo)
    chequear('salud responde y reporta flujos', c == 200 and j.get('flujos', 0) >= 3, j)
    chequear('la fuente es archivo', j.get('fuente') == 'archivo', j.get('fuente'))
    c, cuerpo = pedir('/api/flujos')
    flujos = json.loads(cuerpo)['flujos']
    con_tres = [f for f in flujos if len(f['saltos']) == 3 and f['destino'] == '10.30.0.20']
    chequear('el flujo interno muestra tres saltos (cliente, router, servidor)', len(con_tres) == 1, len(con_tres))
    chequear('el salto del router aparece marcado como NAT', bool(con_tres and con_tres[0]['nat']), con_tres[0]['nat'] if con_tres else None)
    salida = [f for f in flujos if f['destino'] == '10.40.0.10']
    chequear('el flujo de salida a internet tiene dos saltos', len(salida) == 1 and len(salida[0]['saltos']) == 2, len(salida[0]['saltos']) if salida else None)
    bloq = [f for f in flujos if any(s.get('bloqueado') for s in f['saltos'])]
    chequear('el rechazo del firewall se marca como bloqueado', len(bloq) >= 1, len(bloq))
    c, cuerpo = pedir('/api/flujos?q=80')
    filtrados = json.loads(cuerpo)['flujos']
    chequear('el filtro por puerto devuelve solo ese flujo', len(filtrados) == 1 and filtrados[0]['puerto_destino'] == '80', len(filtrados))
    c, cuerpo = pedir('/api/flujos?q=no-existe-9999')
    chequear('un filtro sin coincidencias devuelve lista vacia', json.loads(cuerpo)['flujos'] == [], len(json.loads(cuerpo)['flujos']))
    c, cuerpo = pedir('/')
    chequear('la pagina incluye la topologia y la tabla', 'Visor de rutas' in cuerpo and 'id="filas"' in cuerpo and '<svg' in cuerpo, len(cuerpo))
    req = urllib.request.Request('http://127.0.0.1:%d/api/generar?tipo=interno' % PUERTO, method='POST')
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            c, cuerpo = r.status, r.read().decode()
    except urllib.error.HTTPError as e:
        c, cuerpo = e.code, e.read().decode()
    j = json.loads(cuerpo)
    chequear('generar sin contenedores falla con mensaje, no con error 500', c in (200, 400) and 'detalle' in j, (c, j.get('detalle', '')[:40]))
finally:
    p.send_signal(signal.SIGTERM)
    try: p.wait(timeout=5)
    except Exception: p.kill()
print('RESULTADO: ' + ('todas las pruebas pasan' if fallos == 0 else '%d fallos' % fallos))
sys.exit(fallos)