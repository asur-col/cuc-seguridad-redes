# Paquete del laboratorio B3 — rutas, NAT y visor de tráfico

Cuatro contenedores: `cliente` en la red 10.20.0.0/24, `interno` en la 10.30.0.0/24, `externo` en la 10.40.0.0/24 y
`router` entre las dos. El router aplica `reglas.sh` al arrancar: NAT para que la red interna salga,
permiso al 80 del interno y del externo, y **corte** al 9000 del interno.

```
docker compose up -d
./generar_trafico.sh          # un flujo que entra, uno que sale y uno que se corta
docker exec lab-b3-router iptables -t nat -L POSTROUTING -v -n     # MASQUERADE con contador
docker exec lab-b3-router iptables -L FORWARD -v -n                 # DROP con contador
```

## Visor

El visor es `laboratorios/visor-trafico/`: `colector.py` lee las líneas de `tcpdump` dentro de los
contenedores, agrupa el NAT con la conexión que lo originó y sirve la topología y la tabla de saltos
en `http://127.0.0.1:8099/`. Arranque dentro del laboratorio:

```
python3 colector.py --puerto 8099
```

Sus pruebas están en `laboratorios/visor-trafico/pruebas/` (10 de 10 con un flujo de ejemplo marcado
como formato, y la página sin errores de consola).

## Qué NO hay aquí

- No hay solución de las preguntas del informe: eso lo escribe el estudiante.
- El paquete **no** se ha levantado en el servidor de la academia: está prohibido correr contenedores
  de laboratorio en el servidor del curso. Validado solo el YAML y la sintaxis de los guiones.
