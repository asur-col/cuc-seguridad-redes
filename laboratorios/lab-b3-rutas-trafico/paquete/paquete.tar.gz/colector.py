#!/usr/bin/env python3
"""Visor de rutas y trafico: captura real con tcpdump dentro de los contenedores y la sirve.

No hay animacion: cada salto que se muestra salio de una linea de tcpdump de un contenedor
concreto. Si un contenedor no vio el paquete, ese salto no aparece.

Modos:
  --fuente docker     captura con `docker exec <c> tcpdump ...` en cada contenedor
  --fuente archivo=   lee lineas ya capturadas (para probar el analisis sin contenedores)
"""
import argparse, json, re, shutil, subprocess, sys, threading, time
from collections import OrderedDict, deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

LINEA = re.compile(r'(\d{2}:\d{2}:\d{2}\.\d+).*?(\d+\.\d+\.\d+\.\d+)\.(\d+) > (\d+\.\d+\.\d+\.\d+)\.(\d+)')
# ICMP no lleva puertos: se reconoce aparte para no perder los rechazos del firewall.
LINEA_ICMP = re.compile(r'(\d{2}:\d{2}:\d{2}\.\d+).*?(\d+\.\d+\.\d+\.\d+) > (\d+\.\d+\.\d+\.\d+): (ICMP.*)')
MAX_FLUJOS = 400

class Flujo:
    def __init__(self, clave):
        self.clave = clave
        self.saltos = []
        self.momento = None
        self.primero = None
        self.ultimo = None
    def anadir(self, salto):
        self.saltos.append(salto)
        self.momento = time.monotonic()
        self.primero = self.primero or salto['hora']
        self.ultimo = salto['hora']
    def como_dict(self):
        s, d, sp, dp, proto = self.clave
        return {'origen': s, 'destino': d, 'puerto_origen': sp, 'puerto_destino': dp,
                'protocolo': proto, 'saltos': self.saltos, 'nat': any(x['nat'] for x in self.saltos),
                'bloqueado': any(x['bloqueado'] for x in self.saltos), 'primero': self.primero,
                'ultimo': self.ultimo}

class Captura:
    def __init__(self):
        self.flujos = OrderedDict()
        self.hasta = deque(maxlen=500)
        self.candado = threading.Lock()
        self.fuente = 'docker'
        self.contenedores = []

    def interpretar(self, contenedor, linea):
        m = LINEA.search(linea)
        if m:
            hora, src, sport, dst, dport = m.groups()
            proto = 'tcp' if 'Flags [' in linea else ('udp' if 'UDP' in linea else 'otro')
            bloqueado = False
        else:
            mi = LINEA_ICMP.search(linea)
            if not mi:
                return None
            hora, src, dst, _resto = mi.groups()
            sport = dport = '-'
            proto = 'icmp'
            # Un ICMP de puerto inalcanzable es la forma en que el firewall dice que no.
            bloqueado = 'unreachable' in linea
        salto = {'contenedor': contenedor, 'hora': hora, 'src': src, 'dst': dst,
                 'sport': sport, 'dport': dport, 'proto': proto,
                 'nat': False, 'bloqueado': bloqueado,
                 'linea': linea.strip()[:220]}
        with self.candado:
            clave = (src, dst, sport, dport, proto)
            f = self.flujos.get(clave)
            if f is None:
                # Puede ser el mismo flujo ya traducido por NAT: mismo destino y puerto,
                # otro origen (el del router) y muy poco tiempo despues.
                f = self._continuacion(src, dst, dport, proto)
                if f is not None:
                    salto['nat'] = True
            if f is None:
                f = Flujo(clave)
                self.flujos[clave] = f
                if len(self.flujos) > MAX_FLUJOS:
                    self.flujos.popitem(last=False)
            ya = {(x['contenedor'], x['hora']) for x in f.saltos}
            if (contenedor, hora) not in ya:
                f.anadir(salto)
            self.hasta.append(salto)
        return salto

    def _continuacion(self, src, dst, dport, proto):
        """Flujo abierto compatible con este paquete traducido, o None."""
        ahora = time.monotonic()
        for f in reversed(list(self.flujos.values())):
            if f.momento is None or ahora - f.momento > 3.0:
                continue
            s, d, sp, dp, pr = f.clave
            if pr != proto or d != dst:
                continue
            if dport != '-' and dp != '-' and dp != dport:
                continue
            if src == s:
                continue
            return f
        return None

    def marcar_nat(self, original, traducido):
        """Marca como NAT el salto cuyo par (src,dst) ya no coincide con el primero del flujo."""
        with self.candado:
            for f in self.flujos.values():
                if f.saltos and (f.saltos[0]['src'], f.saltos[0]['dst']) == original:
                    for x in f.saltos:
                        if (x['src'], x['dst']) == traducido:
                            x['nat'] = True
                    return True
        return False

    def listar(self, filtro=None, limitepor=60):
        with self.candado:
            datos = [f.como_dict() for f in self.flujos.values()]
        if filtro:
            datos = [d for d in datos if filtro in json.dumps(d, ensure_ascii=False)]
        return datos[-limitepor:]

def lanzar_docker(cap, contenedor):
    if not shutil.which('docker'):
        sys.stderr.write('docker no esta disponible\n'); return
    cmd = ['docker', 'exec', contenedor, 'tcpdump', '-i', 'any', '-nn', '-e', '-l', '-q']
    while True:
        try:
            p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
            for linea in p.stdout:
                cap.interpretar(contenedor, linea)
            p.wait()
        except FileNotFoundError:
            sys.stderr.write('no se pudo ejecutar docker exec %s\n' % contenedor); return
        except Exception as e:
            sys.stderr.write('captura de %s se corto: %s\n' % (contenedor, e))
        time.sleep(2)

def leer_archivo(cap, ruta):
    for linea in Path(ruta).read_text(encoding='utf-8', errors='replace').splitlines():
        if linea.startswith('#'):
            continue
        cap.interpretar('archivo', linea)

def generar(tipo, contenedores):
    """Genera trafico real desde un contenedor. Solo destinos del laboratorio."""
    destinos = {'interno': ('cliente', 'http://10.30.0.20/'),
                'internet': ('cliente', 'http://10.40.0.10/')}
    if tipo not in destinos:
        return False, 'tipo desconocido'
    c, url = destinos[tipo]
    try:
        r = subprocess.run(['docker', 'exec', c, 'wget', '-q', '-T', '3', '-O', '/dev/null', url],
                           capture_output=True, text=True, timeout=15)
        return True, (r.stderr or 'peticion enviada').strip()[:200]
    except Exception as e:
        return False, str(e)[:200]

def reglas(contenedor='router'):
    """Cuenta de reglas del router: lo que permitio o bloqueo el paquete."""
    try:
        r = subprocess.run(['docker', 'exec', contenedor, 'sh', '-c',
                            'iptables -t nat -L -v -n; echo ---; iptables -L -v -n'],
                           capture_output=True, text=True, timeout=10)
        return r.stdout[:4000]
    except Exception as e:
        return 'no disponible: ' + str(e)[:120]

HTML = (Path(__file__).with_name('plantilla.html').read_text(encoding='utf-8')
        if Path(__file__).with_name('plantilla.html').exists() else '<h1>falta plantilla.html</h1>')

class Manejador(BaseHTTPRequestHandler):
    cap = None
    server_version = 'visor-trafico/1.0'
    def log_message(self, *a):
        return
    def _json(self, datos, codigo=200):
        c = json.dumps(datos, ensure_ascii=False).encode()
        self.send_response(codigo)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(c)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers(); self.wfile.write(c)
    def _html(self, texto, codigo=200):
        c = texto.encode()
        self.send_response(codigo)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(c)))
        self.end_headers(); self.wfile.write(c)
    def do_GET(self):
        u = urlparse(self.path)
        if u.path in ('/', '/index.html'):
            return self._html(HTML)
        if u.path == '/salud':
            return self._json({'ok': True, 'flujos': len(self.cap.flujos), 'fuente': self.cap.fuente})
        if u.path == '/api/flujos':
            q = parse_qs(u.query).get('q', [''])[0]
            return self._json({'flujos': self.cap.listar(q or None), 'fuente': self.cap.fuente})
        if u.path == '/api/reglas':
            return self._json({'router': reglas()})
        self._json({'error': 'no existe'}, 404)
    def do_POST(self):
        u = urlparse(self.path)
        if u.path != '/api/generar':
            return self._json({'error': 'no existe'}, 404)
        tipo = parse_qs(u.query).get('tipo', ['interno'])[0]
        ok, msg = generar(tipo, self.cap.contenedores)
        self._json({'ok': ok, 'detalle': msg}, 200 if ok else 400)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--fuente', default='docker')
    ap.add_argument('--contenedores', default='lab-b3-cliente,lab-b3-router,lab-b3-interno')
    ap.add_argument('--puerto', type=int, default=8099)
    a = ap.parse_args()
    cap = Captura(); cap.contenedores = [x for x in a.contenedores.split(',') if x]
    Manejador.cap = cap
    if a.fuente.startswith('archivo='):
        cap.fuente = 'archivo'
        leer_archivo(cap, a.fuente.split('=', 1)[1])
    else:
        cap.fuente = 'docker'
        for c in cap.contenedores:
            threading.Thread(target=lanzar_docker, args=(cap, c), daemon=True).start()
    httpd = ThreadingHTTPServer(('0.0.0.0', a.puerto), Manejador)
    sys.stderr.write('visor en http://0.0.0.0:%d (fuente=%s)\n' % (a.puerto, cap.fuente))
    httpd.serve_forever()

if __name__ == '__main__':
    raise SystemExit(main())