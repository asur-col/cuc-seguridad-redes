# Paquete del laboratorio C2 — clasificador de tráfico (NDR)

Cuatro scripts y nada más: generar datos, entrenar, predecir y evaluar. Sin internet y sin
dependencias pesadas: solo `numpy` (la guía instala desde `ruedas/`; el paquete no trae las ruedas,
se dejan para la Fase 5 porque hay que descargarlas en un equipo con red).

```
python3 generar_datos.py --filas 4000 --prueba 1000 --semilla 2027 --salida datos
python3 entrenar.py --entrada datos/entrenamiento.csv --modelo modelo.json
python3 predecir.py --modelo modelo.json --entrada datos/prueba.csv --salida predicciones.csv
python3 evaluar.py --real datos/prueba.csv --predicciones predicciones.csv --salida metricas.json
```

Salida real de esta secuencia en el servidor (semilla 2027):

```
matriz vp=346 vn=650 fp=4 fn=0 | exactitud 0.996 | sensibilidad 1.000 | f1 0.994
```

Con `--umbral 0.8` en `evaluar.py`: vp=340 vn=654 fp=0 fn=6, exactitud 0.994, sensibilidad 0.983.
Ese es el ejercicio de B.2: mover el umbral cambia el reparto entre falsos positivos y falsos
negativos, y el informe debe explicar cuál conviene y por qué.

`columnas` y `etiqueta`: `bytes, paquetes, duracion_s, puertos_dst, ratio_entrante`. La etiqueta es
`normal` o `ataque`.

## Verificación

`asur-lab check c2-ndr` recalcula la exactitud desde `datos/prueba.csv` y `predicciones.csv` y la
compara con la declarada en `metricas.json` (tolerancia 0.01). Si el estudiante edita las métricas a
mano, no cuadra y el verificador lo dice. Probado sobre la salida real de arriba: 6 de 6.
