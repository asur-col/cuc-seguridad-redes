#!/usr/bin/env python3
"""Calcula la matriz de confusion y las metricas por clase sobre el conjunto de prueba."""
import argparse, csv, json

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--real", default="datos/prueba.csv")
    ap.add_argument("--predicciones", default="predicciones.csv")
    ap.add_argument("--umbral", type=float, default=0.5)
    ap.add_argument("--salida", default="metricas.json")
    a = ap.parse_args()

    with open(a.real, newline="", encoding="utf-8") as f:
        reales = [f["etiqueta"] for f in csv.DictReader(f)]
    with open(a.predicciones, newline="", encoding="utf-8") as f:
        pred = list(csv.DictReader(f))
    if len(pred) != len(reales):
        raise SystemExit("las predicciones (%d) no coinciden con la prueba (%d)" % (len(pred), len(reales)))

    def etiqueta(fila):
        if "probabilidad" in fila and fila["probabilidad"].strip():
            return "ataque" if float(fila["probabilidad"]) >= a.umbral else "normal"
        return fila["prediccion"]

    vp = sum(1 for r, p in zip(reales, pred) if r == "ataque" and etiqueta(p) == "ataque")
    vn = sum(1 for r, p in zip(reales, pred) if r == "normal" and etiqueta(p) == "normal")
    fp = sum(1 for r, p in zip(reales, pred) if r == "normal" and etiqueta(p) == "ataque")
    fn = sum(1 for r, p in zip(reales, pred) if r == "ataque" and etiqueta(p) == "normal")
    n = len(reales)
    exactitud = (vp + vn) / n
    precision = vp / (vp + fp) if (vp + fp) else 0.0
    sensibilidad = vp / (vp + fn) if (vp + fn) else 0.0
    f1 = 2 * precision * sensibilidad / (precision + sensibilidad) if (precision + sensibilidad) else 0.0

    metricas = {"umbral": a.umbral, "matriz": {"vp": vp, "vn": vn, "fp": fp, "fn": fn},
                "exactitud": round(exactitud, 4), "precision": round(precision, 4),
                "sensibilidad": round(sensibilidad, 4), "f1": round(f1, 4), "filas": n}
    with open(a.salida, "w", encoding="utf-8") as f:
        json.dump(metricas, f, ensure_ascii=False, indent=2)
    print("matriz vp=%d vn=%d fp=%d fn=%d | exactitud %.3f | sensibilidad %.3f | f1 %.3f"
          % (vp, vn, fp, fn, exactitud, sensibilidad, f1))

if __name__ == "__main__":
    main()
