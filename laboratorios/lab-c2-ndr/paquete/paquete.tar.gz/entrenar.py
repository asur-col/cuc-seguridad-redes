#!/usr/bin/env python3
"""Entrena una regresion logistica con numpy y guarda el modelo en JSON."""
import argparse, csv, json
import numpy as np

def cargar(ruta):
    with open(ruta, newline="", encoding="utf-8") as f:
        filas = list(csv.DictReader(f))
    columnas = [c for c in filas[0] if c != "etiqueta"]
    X = np.array([[float(fc[c]) for c in columnas] for fc in filas], dtype=float)
    y = np.array([1.0 if fc["etiqueta"] == "ataque" else 0.0 for fc in filas])
    return columnas, X, y

def sigmoide(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -60, 60)))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--entrada", default="datos/entrenamiento.csv")
    ap.add_argument("--modelo", default="modelo.json")
    ap.add_argument("--epocas", type=int, default=600)
    ap.add_argument("--tasa", type=float, default=0.5)
    a = ap.parse_args()

    columnas, X, y = cargar(a.entrada)
    media = X.mean(axis=0)
    desviacion = X.std(axis=0)
    desviacion[desviacion == 0] = 1.0
    Z = (X - media) / desviacion

    pesos = np.zeros(Z.shape[1])
    sesgo = 0.0
    n = len(y)
    for _ in range(a.epocas):
        error = sigmoide(Z @ pesos + sesgo) - y
        pesos -= a.tasa * (Z.T @ error) / n
        sesgo -= a.tasa * error.mean()

    aciertos = int(((sigmoide(Z @ pesos + sesgo) >= 0.5).astype(float) == y).sum())
    modelo = {"columnas": columnas, "media": media.tolist(), "desviacion": desviacion.tolist(),
              "pesos": pesos.tolist(), "sesgo": float(sesgo)}
    with open(a.modelo, "w", encoding="utf-8") as f:
        json.dump(modelo, f, indent=2)
    print("modelo guardado en %s; exactitud en entrenamiento %.3f con %d filas" % (a.modelo, aciertos / n, n))

if __name__ == "__main__":
    main()
