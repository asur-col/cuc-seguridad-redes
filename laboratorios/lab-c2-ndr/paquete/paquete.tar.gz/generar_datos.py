#!/usr/bin/env python3
"""Genera el trafico de laboratorio: dos clases que se solapan un poco y semilla fija."""
import argparse, csv, os, random

COLUMNAS = ["bytes", "paquetes", "duracion_s", "puertos_dst", "ratio_entrante", "etiqueta"]

def fila_normal(r):
    duracion = round(r.uniform(3, 120), 2)
    tasa = r.uniform(4, 400)
    paquetes = max(4, int(tasa * duracion / 10))
    tamano = r.uniform(300, 1400)
    return [int(paquetes * tamano), paquetes, duracion,
            r.randint(2, 40), round(r.uniform(0.25, 0.80), 3), "normal"]

def fila_ataque(r):
    duracion = round(r.uniform(1, 20), 2)
    tasa = r.uniform(120, 1800)
    paquetes = max(4, int(tasa * duracion))
    tamano = r.uniform(60, 400)
    return [int(paquetes * tamano), paquetes, duracion,
            r.randint(1, 8), round(r.uniform(0.70, 1.0), 3), "ataque"]

def generar(cantidad, proporcion, r):
    filas = []
    for _ in range(cantidad):
        if r.random() < proporcion:
            filas.append(fila_ataque(r))
        else:
            filas.append(fila_normal(r))
    r.shuffle(filas)
    return filas

def escribir(ruta, filas):
    with open(ruta, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(COLUMNAS)
        w.writerows(filas)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--filas", type=int, default=4000, help="filas de entrenamiento")
    ap.add_argument("--prueba", type=int, default=1000, help="filas de prueba")
    ap.add_argument("--ataques", type=float, default=0.35, help="proporcion de ataques")
    ap.add_argument("--semilla", type=int, default=2027)
    ap.add_argument("--salida", default="datos")
    a = ap.parse_args()

    os.makedirs(a.salida, exist_ok=True)
    r = random.Random(a.semilla)
    escribir(os.path.join(a.salida, "entrenamiento.csv"), generar(a.filas, a.ataques, r))
    escribir(os.path.join(a.salida, "prueba.csv"), generar(a.prueba, a.ataques, r))
    print("escrito %s/entrenamiento.csv (%d filas) y %s/prueba.csv (%d filas), semilla %d"
          % (a.salida, a.filas, a.salida, a.prueba, a.semilla))

if __name__ == "__main__":
    main()
