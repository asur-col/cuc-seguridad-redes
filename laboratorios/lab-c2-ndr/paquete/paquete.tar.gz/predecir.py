#!/usr/bin/env python3
"""Predice con el modelo guardado y escribe predicciones.csv (etiqueta y probabilidad)."""
import argparse, csv, json
import numpy as np

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--modelo", default="modelo.json")
    ap.add_argument("--entrada", default="datos/prueba.csv")
    ap.add_argument("--salida", default="predicciones.csv")
    ap.add_argument("--umbral", type=float, default=0.5)
    a = ap.parse_args()

    with open(a.modelo, encoding="utf-8") as f:
        m = json.load(f)
    with open(a.entrada, newline="", encoding="utf-8") as f:
        filas = list(csv.DictReader(f))
    X = np.array([[float(f[c]) for c in m["columnas"]] for f in filas], dtype=float)
    Z = (X - np.array(m["media"])) / np.array(m["desviacion"])
    p = 1.0 / (1.0 + np.exp(-np.clip(Z @ np.array(m["pesos"]) + m["sesgo"], -60, 60)))

    with open(a.salida, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["prediccion", "probabilidad"])
        for valor in p:
            w.writerow(["ataque" if valor >= a.umbral else "normal", round(float(valor), 4)])
    print("escrito %s con %d filas (umbral %.2f)" % (a.salida, len(p), a.umbral))

if __name__ == "__main__":
    main()
