# Paquete del laboratorio C3 — reconocimiento en entorno aislado

Un solo contenedor con un nginx que "quedó" del despliegue: un panel en `/admin/` con listado de
archivos, una carpeta `/backup/` con un respaldo, un `.env` de ejemplo con valores falsos y un
`robots.txt` que confiesa las rutas. El sitio principal responde 200 en `/`.

```
docker compose up -d
curl -s -o /dev/null -w "%{http_code}\n" http://10.50.0.10/
```

La red del compose es `internal: true`: no hay salida a internet. Todo el ejercicio ocurre entre
10.50.0.0/24 y el propio anfitrión.

## Regla de oro del laboratorio

El objetivo es **cerrar lo que sobra sin apagar el sitio**. El verificador comprueba las dos cosas:
el 200 de `/` y que las rutas de despliegue ya no devuelvan contenido.

## Qué NO hay aquí

- No hay solución escrita: qué archivos borrar, qué directivas cambiar y qué códigos dejar es el
  trabajo del estudiante.
- Los valores de `.env` son de mentira a propósito.
- No se ha levantado en el servidor del curso: prohibido. Solo YAML y sintaxis validados.
